# Visual Guide - Responsive Player

## Desktop Experience (≥768px)

### FloatingPlayer - Minimized Mode

```
┌─────────────────────────────────────────┐
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│                                    ┌──┐ │
│                                    │🎵│ │ ← 64x64 circle
│                                    └──┘ │
└─────────────────────────────────────────┘
```

### FloatingPlayer - Compact Mode

```
┌─────────────────────────────────────────┐
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│                    ┌──────────────────┐ │
│                    │ ▓▓ Title         │ │
│                    │ ▓▓ Artist        │ │
│                    │ 0:45 ▶ 3:20 ⤢ − ✕│ │ ← 320px wide
│                    └──────────────────┘ │
└─────────────────────────────────────────┘
```

### FloatingPlayer - Expanded Mode

```
┌─────────────────────────────────────────┐
│                                         │
│                                         │
│                  ┌────────────────────┐ │
│                  │ Now Playing     ▼ ✕│ │
│                  │                    │ │
│                  │   ┌──────────┐    │ │
│                  │   │          │    │ │
│                  │   │  Album   │    │ │ ← 384px wide
│                  │   │   Art    │    │ │
│                  │   │          │    │ │
│                  │   └──────────┘    │ │
│                  │                    │ │
│                  │  Title             │ │
│                  │  Artist            │ │
│                  │  ━━━━━━━━━━━━━━━  │ │
│                  │  0:45        3:20  │ │
│                  │   ⏪  ▶  ⏩       │ │
│                  └────────────────────┘ │
└─────────────────────────────────────────┘
```

## Mobile Experience (<768px)

### MiniPlayer - Bottom Bar

```
┌─────────────────────┐
│                     │
│                     │
│   Content Area      │
│                     │
│                     │
│                     │
│                     │
├─────────────────────┤
│ ▓ Title      ▶  ✕ │ ← Fixed bottom bar (72px)
└─────────────────────┘
```

### FullPlayerModal - Expanded

```
┌─────────────────────┐
│        ▼            │ ← Tap to collapse
├─────────────────────┤
│                     │
│                     │
│   ┌───────────┐     │
│   │           │     │
│   │  Album    │     │
│   │   Art     │     │
│   │           │     │
│   └───────────┘     │
│                     │
│      Title          │
│      Artist         │
│                     │
│  ━━━━━━━━━━━━━━━   │
│  0:45        3:20   │
│                     │
│   ⏪  ▶  ⏩        │
│                     │
└─────────────────────┘
```

## Responsive Transition

### Desktop → Mobile (Resize to <768px)

```
Desktop (1920px)              Mobile (375px)
┌──────────────────┐          ┌─────────┐
│                  │          │         │
│            ┌───┐ │          │         │
│            │ ▓ │ │   →      │         │
│            └───┘ │          ├─────────┤
│                  │          │ ▓  ▶  ✕│
└──────────────────┘          └─────────┘
FloatingPlayer               MiniPlayer
```

### Mobile → Desktop (Resize to ≥768px)

```
Mobile (375px)               Desktop (1920px)
┌─────────┐                 ┌──────────────────┐
│         │                 │                  │
│         │                 │            ┌───┐ │
│         │        →        │            │ ▓ │ │
├─────────┤                 │            └───┘ │
│ ▓  ▶  ✕│                 │                  │
└─────────┘                 └──────────────────┘
MiniPlayer                  FloatingPlayer
```

## Dev Helper Indicator

### Bottom-Left Corner (Development Only)

```
┌─────────────────────────────────────────┐
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│                                         │
│ ┌──────────────────────┐                │
│ │ Size: 1920x1080      │                │
│ │ Mode: Desktop        │                │
│ │ Breakpoint: 768px    │                │
│ └──────────────────────┘                │
└─────────────────────────────────────────┘
```

## User Interactions

### Desktop - Dragging

```
1. Mouse down on header
   ┌────────────┐
   │ ⬇ Grab     │
   └────────────┘

2. Move mouse
   ┌────────────┐
        ↓
   ┌────────────┐
   │ Moving...  │
   └────────────┘

3. Mouse up
   ┌────────────┐
   │ ⬆ Release  │
   └────────────┘
   Position saved!
```

### Desktop - Mode Switching

```
Minimized          Compact           Expanded
   ┌──┐              ┌────┐            ┌──────┐
   │🎵│  → click →   │ ▓  │  → ⤢ →    │ ▓▓▓  │
   └──┘              │ ▶  │            │ ▶▶▶  │
                     └────┘            └──────┘
```

### Mobile - Expanding

```
MiniPlayer                FullPlayerModal
┌─────────┐              ┌─────────┐
│         │              │    ▼    │
├─────────┤              ├─────────┤
│ ▓  ▶  ✕│  → tap →    │         │
└─────────┘              │   ▓▓▓   │
                         │   ▶▶▶   │
                         └─────────┘
```

## Breakpoint Visualization

```
Screen Width (px)
0        375      768      1024     1920
├─────────┼────────┼─────────┼─────────┤
│  Mobile │ Mobile │      Desktop      │
│         │        │                   │
└─────────┴────────┴───────────────────┘
          ↑
          Breakpoint (768px)

< 768px  = Mobile  (MiniPlayer)
≥ 768px  = Desktop (FloatingPlayer)
```

## Color Coding

### Desktop (FloatingPlayer)

- Background: `bg-neutral-800` (dark gray)
- Progress: `bg-accent-primary` (green)
- Text: `text-white`
- Buttons: `bg-white` (play/pause)

### Mobile (MiniPlayer)

- Background: `bg-neutral-800` (dark gray)
- Progress: `bg-accent-primary` (green)
- Text: `text-white`
- Buttons: `bg-neutral-700` (darker gray)

### Dev Helper

- Background: `bg-black/90` (semi-transparent)
- Desktop mode: `text-blue-400` (blue)
- Mobile mode: `text-orange-400` (orange)

## Layout Positioning

### Desktop FloatingPlayer

```
Position: fixed
Default: bottom-right
Constraints: Within viewport bounds
Draggable: Yes
Z-index: 50
```

### Mobile MiniPlayer

```
Position: fixed
Location: bottom: 0
Width: 100%
Height: 72px
Z-index: 50
```

### Mobile FullPlayerModal

```
Position: fixed
Location: inset-0 (full screen)
Width: 100%
Height: 100vh
Z-index: 50
```

## Animation States

### FloatingPlayer Transitions

```
Minimized ⟷ Compact ⟷ Expanded
   ↓           ↓          ↓
 64x64      320px      384px
 circle     mini       full
```

### MiniPlayer Transitions

```
Hidden → Slide Up → Visible
         (300ms)

Visible → Fade Out → Hidden
          (200ms)
```

### Modal Transitions

```
Closed → Fade In → Open
         (300ms)

Open → Fade Out → Closed
       (200ms)
```

## Responsive Grid

```
Desktop Layout (≥768px)
┌─────────────────────────────────────┐
│ Header                              │
├─────────────────────────────────────┤
│ ┌────┐ ┌────┐ ┌────┐ ┌────┐       │
│ │ 🎵 │ │ 🎵 │ │ 🎵 │ │ 🎵 │       │
│ └────┘ └────┘ └────┘ └────┘       │
│                                     │
│ ┌────┐ ┌────┐ ┌────┐ ┌────┐       │
│ │ 🎵 │ │ 🎵 │ │ 🎵 │ │ 🎵 │       │
│ └────┘ └────┘ └────┘ └────┘       │
│                                     │
│                          ┌────┐    │
│                          │ ▓  │    │ ← FloatingPlayer
│                          └────┘    │
└─────────────────────────────────────┘

Mobile Layout (<768px)
┌─────────┐
│ Header  │
├─────────┤
│ ┌─────┐ │
│ │ 🎵  │ │
│ └─────┘ │
│ ┌─────┐ │
│ │ 🎵  │ │
│ └─────┘ │
│ ┌─────┐ │
│ │ 🎵  │ │
│ └─────┘ │
├─────────┤
│ ▓  ▶  ✕│ ← MiniPlayer
└─────────┘
```

## State Indicators

### Playing

```
Desktop: ▶ → ⏸ (white circle)
Mobile:  ▶ → ⏸ (gray circle)
```

### Loading

```
Desktop: ⟳ (spinning)
Mobile:  ⟳ (spinning)
```

### Error

```
Desktop: ⚠ (warning icon)
Mobile:  ⚠ (warning icon)
```

## Touch Targets (Mobile)

```
Minimum Size: 44x44px (iOS guideline)

MiniPlayer:
┌──────────────────┐
│ ▓▓  Title   ▶  ✕│
│ 44px 44px  44px │
└──────────────────┘

FullPlayerModal:
┌──────────────────┐
│       ▼          │ 44px
├──────────────────┤
│                  │
│    ⏪  ▶  ⏩    │ 56px each
│                  │
└──────────────────┘
```

## Accessibility Focus Order

### Desktop (FloatingPlayer - Expanded)

```
1. Header (draggable area)
2. Collapse button
3. Close button
4. Seek slider
5. Skip backward button
6. Play/pause button
7. Skip forward button
```

### Mobile (MiniPlayer)

```
1. Entire player (tap to expand)
2. Play/pause button
3. Close button
```

### Mobile (FullPlayerModal)

```
1. Close button
2. Seek slider
3. Skip backward button
4. Play/pause button
5. Skip forward button
```
